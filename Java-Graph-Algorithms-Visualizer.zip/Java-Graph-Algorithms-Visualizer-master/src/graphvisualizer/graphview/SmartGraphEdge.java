
package graphvisualizer.graphview;

import graphvisualizer.graph.Edge;
import graphvisualizer.graph.Vertex;

public interface SmartGraphEdge<E, V> extends SmartStylableNode {
    
     /**
     * Returns the underlying (stored reference) graph edge.
     * 
     * @return edge reference 
     * 
     * @see SmartGraphPanel
     */
    public Edge<E, V> getUnderlyingEdge();
}
