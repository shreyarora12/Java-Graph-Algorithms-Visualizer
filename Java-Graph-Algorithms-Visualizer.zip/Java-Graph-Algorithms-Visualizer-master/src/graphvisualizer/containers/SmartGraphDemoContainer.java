
package graphvisualizer.containers;

import javafx.scene.control.CheckBox;
import javafx.scene.control.Menu;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import graphvisualizer.graphview.SmartGraphPanel;


public class SmartGraphDemoContainer extends BorderPane {
    private MenuPane menu;

    public SmartGraphDemoContainer(SmartGraphPanel graphView) {
        setCenter(new ContentResizerPane(graphView));
        menu = new MenuPane();
        setRight(menu);
    }

    public MenuPane getMenu() {
        return menu;
    }
}
